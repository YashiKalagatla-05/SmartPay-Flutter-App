# SmartPay – Expense & Rewards Tracker App

SmartPay is a Flutter-based mobile app that helps users manage expenses, track payments, and earn rewards for every timely transaction. Inspired by CRED, the app focuses on clean UI and secure payment flow.

## 🚀 Features
- Firebase Authentication
- Real-time Expense Tracking
- Rewards System for On-Time Payments
- Razorpay Mock Payment Integration
- Dark/Light Mode
- Push Notifications

## 🛠️ Tech Stack
Flutter, Dart, Firebase, Razorpay API, Provider, Lottie
